# DIDmultiplegtDYN 

## Changes in version 1.0.0

First official R release.

## Changes in version 1.0.1

+ Stronger syntax checks.

+ Fixed minor bugs related to predict_het and same_switchers_pl options.

## Changes in version 1.0.2

+ Added returns descriptions to Rd files.

## Changes in version 1.0.3

+ Minor changes to in-console printing statements.

## Changes in version 1.0.4

+ Fixed bugs for unbalanced panels.

## Changes in version 1.0.5

+ Added option to compute bootstrap standard errors

+ Fixed minor bugs

## Changes in version 1.0.6

+ Added by_path option.

## Changes in version 1.0.7

+ Added average number of cumulative effects

+ Added compatibility with rnames to enhance results browsing experience
