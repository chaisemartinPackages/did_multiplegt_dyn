# DIDmultiplegtDYN 

## Changes in version 1.0.0

First official R release.

## Changes in version 1.0.1

+ Stronger syntax checks.

+ Fixed minor bugs related to predict_het and same_switchers_pl options.