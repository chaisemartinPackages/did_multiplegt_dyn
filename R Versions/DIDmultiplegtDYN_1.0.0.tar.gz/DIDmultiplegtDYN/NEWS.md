# DIDmultiplegtDYN 

## Changes in version 1.0.0

First official R release.
