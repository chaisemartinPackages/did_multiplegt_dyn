# DIDmultiplegtDYN 

## Changes in version 1.0.0

First official R release.

## Changes in version 1.0.1

+ Stronger syntax checks.

+ Fixed minor bugs related to predict_het and same_switchers_pl options.

## Changes in version 1.0.2

+ Added returns descriptions to Rd files.

## Changes in version 1.0.3

+ Minor changes to in-console printing statements.

## Changes in version 1.0.4

+ Fixed bugs for unbalanced panels.